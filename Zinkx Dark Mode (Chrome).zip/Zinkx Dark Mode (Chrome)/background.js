// background.js
// Şu an için boş
