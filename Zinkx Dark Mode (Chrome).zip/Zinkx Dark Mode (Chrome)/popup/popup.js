let isDarkMode = false;
let isBoldText = false;

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(['darkMode', 'boldText', 'selectedFont'], (result) => {
    isDarkMode = result.darkMode || false;
    isBoldText = result.boldText || false;
    const selectedFont = result.selectedFont || 'Arial';

    document.getElementById('toggleDarkMode').checked = isDarkMode;
    document.getElementById('boldText').checked = isBoldText;
    document.getElementById('fontSelector').value = selectedFont;
  });
});

function sendMessageToActiveTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
        if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError);
        } else if (response) {
          console.log(response.status);
        }
      });
    }
  });
}

document.getElementById('toggleDarkMode').addEventListener('change', () => {
  isDarkMode = !isDarkMode;
  chrome.storage.local.set({ darkMode: isDarkMode }, () => {
    sendMessageToActiveTab({ action: "toggleDarkMode" });
  });
});

document.getElementById('boldText').addEventListener('change', () => {
  isBoldText = !isBoldText;
  chrome.storage.local.set({ boldText: isBoldText }, () => {
    sendMessageToActiveTab({ action: "boldText" });
  });
});

document.getElementById('fontSelector').addEventListener('change', (event) => {
  const selectedFont = event.target.value;
  chrome.storage.local.set({ selectedFont }, () => {
    sendMessageToActiveTab({ action: "changeFont", font: selectedFont });
  });
});

document.getElementById('githubButton').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://github.com/zinkxx' });
});

document.getElementById('websiteButton').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://devtechnic.online' });
});
